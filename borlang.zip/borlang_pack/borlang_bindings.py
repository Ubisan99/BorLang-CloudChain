"""
BoRLang Bindings — integrazione con ecosistema Python principale.
Wrapping slim di: Pandas, PyTorch, Hugging Face, LangChain, Plotly, Scrapy, etc.

Ogni binding è una funzione Python che BoRLang chiama nativamente.
Niente boilerplate — just call and go.
"""

import sys
import json
from typing import Any, Dict, List, Optional

# ============================================================
# PANDAS / POLARS — DataFrame manipulation
# ============================================================

def df_read_csv(path: str) -> Dict[str, Any]:
    """Read CSV → list of dicts (row-oriented)"""
    try:
        import pandas as pd
        df = pd.read_csv(path)
        return {
            "rows": df.to_dict('records'),
            "shape": list(df.shape),
            "columns": list(df.columns),
            "dtypes": {col: str(df[col].dtype) for col in df.columns}
        }
    except Exception as e:
        return {"error": str(e)}

def df_to_csv(data: List[Dict], path: str) -> bool:
    """Write list of dicts to CSV"""
    try:
        import pandas as pd
        df = pd.DataFrame(data)
        df.to_csv(path, index=False)
        return True
    except:
        return False

def df_groupby(rows: List[Dict], by: str, agg: str = "count") -> Dict:
    """Group rows by column + aggregate (count|sum|mean|max|min)"""
    try:
        import pandas as pd
        df = pd.DataFrame(rows)
        if agg == "count":
            result = df.groupby(by).size().to_dict()
        elif agg == "sum":
            result = df.groupby(by).sum().to_dict('index')
        elif agg == "mean":
            result = df.groupby(by).mean().to_dict('index')
        else:
            result = {}
        return {"result": result}
    except Exception as e:
        return {"error": str(e)}

def df_filter(rows: List[Dict], column: str, operator: str, value: Any) -> List[Dict]:
    """Filter rows: column [==,!=,<,>,<=,>=,contains] value"""
    try:
        import pandas as pd
        df = pd.DataFrame(rows)
        if operator == "==":
            mask = df[column] == value
        elif operator == "!=":
            mask = df[column] != value
        elif operator == "<":
            mask = df[column] < value
        elif operator == ">":
            mask = df[column] > value
        elif operator == "<=":
            mask = df[column] <= value
        elif operator == ">=":
            mask = df[column] >= value
        elif operator == "contains":
            mask = df[column].astype(str).str.contains(str(value), na=False)
        else:
            return []
        return df[mask].to_dict('records')
    except:
        return []

def df_sort(rows: List[Dict], by: str, desc: bool = False) -> List[Dict]:
    """Sort rows by column"""
    try:
        import pandas as pd
        df = pd.DataFrame(rows)
        return df.sort_values(by, ascending=not desc).to_dict('records')
    except:
        return rows

def df_head(rows: List[Dict], n: int = 5) -> List[Dict]:
    """First N rows"""
    return rows[:n]

def df_tail(rows: List[Dict], n: int = 5) -> List[Dict]:
    """Last N rows"""
    return rows[-n:]

# ============================================================
# PLOTLY / MATPLOTLIB — Visualization
# ============================================================

def plot_line(x: List, y: List, title: str = "", filename: str = None) -> str:
    """Line chart. Returns HTML or saves to file."""
    try:
        import plotly.graph_objects as go
        fig = go.Figure(data=go.Scatter(x=x, y=y, mode='lines'))
        fig.update_layout(title=title)
        html = fig.to_html()
        if filename:
            fig.write_html(filename)
            return f"saved to {filename}"
        return html
    except Exception as e:
        return f"error: {e}"

def plot_scatter(x: List, y: List, title: str = "", filename: str = None) -> str:
    """Scatter plot"""
    try:
        import plotly.graph_objects as go
        fig = go.Figure(data=go.Scatter(x=x, y=y, mode='markers'))
        fig.update_layout(title=title)
        if filename:
            fig.write_html(filename)
            return f"saved to {filename}"
        return fig.to_html()
    except Exception as e:
        return f"error: {e}"

def plot_bar(labels: List[str], values: List, title: str = "", filename: str = None) -> str:
    """Bar chart"""
    try:
        import plotly.graph_objects as go
        fig = go.Figure(data=go.Bar(x=labels, y=values))
        fig.update_layout(title=title)
        if filename:
            fig.write_html(filename)
            return f"saved to {filename}"
        return fig.to_html()
    except Exception as e:
        return f"error: {e}"

# ============================================================
# PYTORCH / TRANSFORMERS — Deep Learning & GenAI
# ============================================================

def hf_pipeline(task: str, model: str = None) -> Dict:
    """Hugging Face pipeline (text-classification, ner, translation, etc)"""
    try:
        from transformers import pipeline
        p = pipeline(task, model=model)
        return {"pipeline": p, "task": task, "model": model or "default"}
    except Exception as e:
        return {"error": str(e)}

def hf_classify(text: str, model: str = "distilbert-base-uncased-finetuned-sst-2-english") -> Dict:
    """Text classification (sentiment, etc)"""
    try:
        from transformers import pipeline
        clf = pipeline("text-classification", model=model)
        result = clf(text)[0]
        return {"label": result["label"], "score": result["score"]}
    except Exception as e:
        return {"error": str(e)}

def hf_ner(text: str, model: str = "dslim/bert-base-multilingual-cased-ner") -> List[Dict]:
    """Named entity recognition"""
    try:
        from transformers import pipeline
        ner = pipeline("ner", model=model)
        return ner(text)
    except Exception as e:
        return [{"error": str(e)}]

def hf_summarize(text: str, model: str = "facebook/bart-large-cnn") -> str:
    """Text summarization"""
    try:
        from transformers import pipeline
        summarizer = pipeline("summarization", model=model)
        result = summarizer(text, max_length=150, min_length=50, do_sample=False)
        return result[0]["summary_text"] if result else ""
    except Exception as e:
        return f"error: {e}"

def hf_translate(text: str, src: str = "en", tgt: str = "fr") -> str:
    """Translation"""
    try:
        from transformers import pipeline
        translator = pipeline("translation", model=f"Helsinki-NLP/opus-mt-{src}-{tgt}")
        result = translator(text)
        return result[0]["translation_text"] if result else ""
    except Exception as e:
        return f"error: {e}"

def hf_embed(texts: List[str], model: str = "sentence-transformers/all-MiniLM-L6-v2") -> List[List[float]]:
    """Sentence embeddings via SBERT"""
    try:
        from sentence_transformers import SentenceTransformer
        m = SentenceTransformer(model)
        embeddings = m.encode(texts)
        return embeddings.tolist()
    except Exception as e:
        return []

# ============================================================
# LANGCHAIN / LITELLM — LLM orchestration
# ============================================================

def llm_chat(message: str, model: str = "ollama:qwen2.5:14b", system: str = None) -> str:
    """Chat with LLM (local Ollama or remote via LiteLLM)"""
    try:
        import litellm
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": message})
        response = litellm.completion(model=model, messages=messages)
        return response.choices[0].message.content
    except Exception as e:
        return f"error: {e}"

def llm_batch_classify(texts: List[str], labels: List[str], model: str = "ollama:qwen2.5:7b") -> List[str]:
    """Classify multiple texts into label categories"""
    try:
        import litellm
        results = []
        for text in texts:
            prompt = f"Classify this text as one of {labels}: {text}"
            response = litellm.completion(model=model, messages=[{"role": "user", "content": prompt}])
            results.append(response.choices[0].message.content)
        return results
    except Exception as e:
        return []

def llm_extract(text: str, schema: Dict, model: str = "ollama:qwen2.5:14b") -> Dict:
    """Extract structured data from text using JSON schema"""
    try:
        import litellm
        import json
        prompt = f"Extract JSON matching this schema from text:\nSchema: {json.dumps(schema)}\nText: {text}"
        response = litellm.completion(model=model, messages=[{"role": "user", "content": prompt}])
        try:
            return json.loads(response.choices[0].message.content)
        except:
            return {"raw": response.choices[0].message.content}
    except Exception as e:
        return {"error": str(e)}

# ============================================================
# VECTOR DATABASES — Chroma, Qdrant, FAISS
# ============================================================

def vec_db_create_chroma(name: str = "default") -> Dict:
    """Create Chroma in-memory collection"""
    try:
        import chromadb
        client = chromadb.Client()
        collection = client.create_collection(name=name, metadata={"hnsw:space": "cosine"})
        return {"collection": collection, "type": "chroma", "name": name}
    except Exception as e:
        return {"error": str(e)}

def vec_db_add(collection, texts: List[str], ids: List[str] = None, metadatas: List[Dict] = None) -> bool:
    """Add documents to vector collection"""
    try:
        if ids is None:
            ids = [str(i) for i in range(len(texts))]
        collection.add(documents=texts, ids=ids, metadatas=metadatas or [{}]*len(texts))
        return True
    except:
        return False

def vec_db_query(collection, query_text: str, k: int = 5) -> List[Dict]:
    """Query vector collection, return top K results"""
    try:
        results = collection.query(query_texts=[query_text], n_results=k)
        hits = []
        for i in range(len(results['ids'][0])):
            hits.append({
                "id": results['ids'][0][i],
                "document": results['documents'][0][i],
                "distance": results['distances'][0][i] if 'distances' in results else 0
            })
        return hits
    except:
        return []

# ============================================================
# NLTK / spaCy — NLP
# ============================================================

def nlp_tokenize(text: str) -> List[str]:
    """Tokenize text into words"""
    try:
        import nltk
        from nltk.tokenize import word_tokenize
        return word_tokenize(text)
    except:
        return text.split()

def nlp_pos_tag(text: str) -> List[tuple]:
    """Part-of-speech tagging"""
    try:
        import nltk
        from nltk.tokenize import word_tokenize
        from nltk import pos_tag
        tokens = word_tokenize(text)
        return pos_tag(tokens)
    except:
        return []

def nlp_ner_spacy(text: str, model: str = "en_core_web_sm") -> List[Dict]:
    """Named entity recognition via spaCy"""
    try:
        import spacy
        nlp = spacy.load(model)
        doc = nlp(text)
        return [{"text": ent.text, "label": ent.label_} for ent in doc.ents]
    except Exception as e:
        return [{"error": str(e)}]

def nlp_sentiment(text: str) -> Dict:
    """Sentiment analysis via TextBlob"""
    try:
        from textblob import TextBlob
        blob = TextBlob(text)
        return {"polarity": blob.sentiment.polarity, "subjectivity": blob.sentiment.subjectivity}
    except:
        return {"error": "TextBlob failed"}

# ============================================================
# WEB SCRAPING — Requests, BeautifulSoup, Selenium
# ============================================================

def scrape_html(url: str) -> str:
    """Fetch HTML from URL"""
    try:
        import requests
        response = requests.get(url, timeout=10)
        return response.text
    except Exception as e:
        return f"error: {e}"

def scrape_parse_html(html: str, selector: str) -> List[str]:
    """Parse HTML with CSS selector"""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        elements = soup.select(selector)
        return [elem.get_text(strip=True) for elem in elements]
    except:
        return []

def scrape_json(url: str) -> Dict:
    """Fetch JSON from URL"""
    try:
        import requests
        response = requests.get(url, timeout=10)
        return response.json()
    except Exception as e:
        return {"error": str(e)}

# ============================================================
# FASTAPI / STREAMLIT — Web apps
# ============================================================

def web_streamlit_run(script_path: str) -> str:
    """Run Streamlit app (blocking)"""
    import subprocess
    try:
        subprocess.run(["streamlit", "run", script_path], check=True)
        return "ok"
    except Exception as e:
        return f"error: {e}"

def web_fastapi_endpoint(method: str, path: str, handler_code: str) -> Dict:
    """Register FastAPI endpoint (mock — actual would need app instance)"""
    return {"method": method, "path": path, "registered": True}

# ============================================================
# DATA VALIDATION — Pydantic
# ============================================================

def validate_schema(data: Dict, schema: Dict) -> bool:
    """Validate data against Pydantic-style schema"""
    try:
        from pydantic import create_model, ValidationError
        # Build Pydantic model from schema
        field_definitions = {}
        for field, typ in schema.items():
            if typ == "string":
                field_definitions[field] = (str, ...)
            elif typ == "integer":
                field_definitions[field] = (int, ...)
            elif typ == "float":
                field_definitions[field] = (float, ...)
            elif typ == "bool":
                field_definitions[field] = (bool, ...)
        Model = create_model('DynamicModel', **field_definitions)
        Model(**data)
        return True
    except:
        return False

# ============================================================
# Registry: map BoRLang function names to Python callables
# ============================================================

BINDINGS = {
    # Data manipulation
    "df_read_csv": df_read_csv,
    "df_to_csv": df_to_csv,
    "df_groupby": df_groupby,
    "df_filter": df_filter,
    "df_sort": df_sort,
    "df_head": df_head,
    "df_tail": df_tail,
    
    # Visualization
    "plot_line": plot_line,
    "plot_scatter": plot_scatter,
    "plot_bar": plot_bar,
    
    # Deep Learning / GenAI
    "hf_pipeline": hf_pipeline,
    "hf_classify": hf_classify,
    "hf_ner": hf_ner,
    "hf_summarize": hf_summarize,
    "hf_translate": hf_translate,
    "hf_embed": hf_embed,
    
    # LLM Orchestration
    "llm_chat": llm_chat,
    "llm_batch_classify": llm_batch_classify,
    "llm_extract": llm_extract,
    
    # Vector DBs
    "vec_db_create_chroma": vec_db_create_chroma,
    "vec_db_add": vec_db_add,
    "vec_db_query": vec_db_query,
    
    # NLP
    "nlp_tokenize": nlp_tokenize,
    "nlp_pos_tag": nlp_pos_tag,
    "nlp_ner_spacy": nlp_ner_spacy,
    "nlp_sentiment": nlp_sentiment,
    
    # Web Scraping
    "scrape_html": scrape_html,
    "scrape_parse_html": scrape_parse_html,
    "scrape_json": scrape_json,
    
    # Web Apps
    "web_streamlit_run": web_streamlit_run,
    "web_fastapi_endpoint": web_fastapi_endpoint,
    
    # Validation
    "validate_schema": validate_schema,
}
